#!/bin/env bash

xdg-open https://wiki.archlinux.org/
