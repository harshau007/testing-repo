#!/bin/env bash

xdg-open https://aur.archlinux.org/