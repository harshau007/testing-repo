#!/bin/env bash

xdg-open https://www.github.com/tcet-opensource/tcet-linux
