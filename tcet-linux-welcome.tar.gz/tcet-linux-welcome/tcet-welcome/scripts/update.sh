#!/bin/env bash

xfce4-terminal -e "pkexec pacman --noconfirm -Syyu"

