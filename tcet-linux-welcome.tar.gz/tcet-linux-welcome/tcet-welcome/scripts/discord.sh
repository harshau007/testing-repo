#!/bin/env bash

xdg-open https://discord.gg/r7ZhAREg2M
